const choices = ['rock', 'paper', 'scissors'];
let userScore = localStorage.getItem('userScore') || 0;
let computerScore = localStorage.getItem('computerScore') || 0;

document.getElementById('your-score').textContent = userScore;
document.getElementById('computer-score').textContent = computerScore;

const playAgainBtn = document.getElementById('play-again');
const retryBtn = document.getElementById('retry');

document.querySelectorAll('.choice').forEach(button => {
  button.addEventListener('click', () => {
    const userChoice = button.id;
    const computerChoice = choices[Math.floor(Math.random() * 3)];
    showComputerChoice(computerChoice);
    determineWinner(userChoice, computerChoice);
  });
});

function showComputerChoice(computerChoice) {
  const computerChoiceText = document.getElementById('computer-choice');
  computerChoiceText.textContent = computerChoice;
}

function determineWinner(userChoice, computerChoice) {
  const resultMessage = document.getElementById('result-message');
  const celebrationMessage = document.getElementById('celebration-message');
  playAgainBtn.classList.remove('visible');
  retryBtn.classList.remove('visible');
  celebrationMessage.classList.remove('visible');

  if (userChoice === computerChoice) {
    resultMessage.textContent = "It's a draw!";
    showRetryButton(); // Show Retry button on a tie
  } else if (
    (userChoice === 'rock' && computerChoice === 'scissors') ||
    (userChoice === 'scissors' && computerChoice === 'paper') ||
    (userChoice === 'paper' && computerChoice === 'rock')
  ) {
    userScore++;
    localStorage.setItem('userScore', userScore);
    document.getElementById('your-score').textContent = userScore;
    resultMessage.textContent = 'You win!';
    triggerCelebration();
    showPlayAgainButton(); // Show Play Again button on win
  } else {
    computerScore++;
    localStorage.setItem('computerScore', computerScore);
    document.getElementById('computer-score').textContent = computerScore;
    resultMessage.textContent = 'You lose!';
    showPlayAgainButton(); // Show Play Again button on loss
  }
}

function triggerCelebration() {
  const celebrationMessage = document.getElementById('celebration-message');
  celebrationMessage.classList.add('visible');
}

function showPlayAgainButton() {
  playAgainBtn.classList.add('visible');
}

function showRetryButton() {
  retryBtn.classList.add('visible');
}

// Reset the game when "Play Again" button is clicked
playAgainBtn.addEventListener('click', resetGame);

// Reset the game when "Retry" button is clicked
retryBtn.addEventListener('click', resetGame);

function resetGame() {
  const resultMessage = document.getElementById('result-message');
  const computerChoiceText = document.getElementById('computer-choice');
  const celebrationMessage = document.getElementById('celebration-message');
  
  // Reset UI elements
  resultMessage.textContent = '';
  computerChoiceText.textContent = '';
  celebrationMessage.classList.remove('visible');
  playAgainBtn.classList.remove('visible');
  retryBtn.classList.remove('visible');
}
